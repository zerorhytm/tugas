package com.christianw.coba;

import android.view.View;

public interface OnItemClickListener {
    void onClick(View view, int position);
}
