package com.christianw.coba;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ObatHolder> {

    private ArrayList<Order> myadapter;
    Context mcontext,context;
    private OnItemClickListener onItemClickListener;

    // Constructor MyAdapter
    public MyAdapter(ArrayList<Order> serie) {
        this.context = context;myadapter = serie;
    }

    @Override
    public MyAdapter.ObatHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        mcontext = viewGroup.getContext();

        View inflatedView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.mycustom, viewGroup, false);
        return new ObatHolder(inflatedView);
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    @Override
    public void onBindViewHolder(MyAdapter.ObatHolder holder, int i) {
        Order itemPhoto = myadapter.get(i);
        holder.choose(itemPhoto);
    }

    @Override
    public int getItemCount() {
        return myadapter.size();
    }

    public class ObatHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView txtNama,txtTopping,txtHarga;
        private Order orderku;

        public ObatHolder(@NonNull final View itemView) {
            super(itemView);
            txtNama=itemView.findViewById(R.id.txtNamaBarang);
            txtTopping=itemView.findViewById(R.id.txtTopping);
            txtHarga=itemView.findViewById(R.id.txtHargaBarang);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (onItemClickListener != null) {
                        onItemClickListener.onClick(itemView, getAdapterPosition());
                    }
                }
            });
            //v.setOnClickListener(this);
        }

        //5
        @Override
        public void onClick(View v) {

            /*Context context = itemView.getContext();
            Intent showPhotoIntent = new Intent(context, Pelicula.class);
            showPhotoIntent.putExtra(PHOTO_KEY, peli);
            context.startActivity(showPhotoIntent);*/


        }

        public void choose(Order mserie) {
            orderku = mserie;

            txtNama.setText(orderku.getQty()+" "+orderku.getType());
            txtTopping.setText("with "+orderku.getTopping());
            txtHarga.setText("Rp. "+orderku.getSubtotal());


            /*
            if(pilihObat.getFoto().equalsIgnoreCase("")) {
                mfoto.setImageResource(R.drawable.defaultproduct);
            }
            else {
                GlobalSetting.DownloadImage imgtask = new GlobalSetting.DownloadImage(mfoto);
                imgtask.execute(mcontext.getString(R.string.imageaddress) +"/produk/" + pilihObat.getFoto());
            }
            */
            //mnamakategori.setText(pilihObat.getNamakategori());
            //mnamaobat.setText(pilihObat.getNamaobat());
            //mhargaobat.setText(GlobalSetting.makeDecimal(pilihObat.getHarga()));
        }
    }
}
