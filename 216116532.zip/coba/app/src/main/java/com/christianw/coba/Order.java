package com.christianw.coba;

public class Order {

    String type,topping;
    int qty;
    int subtotal;

    public Order(String type, String topping, int qty, int subtotal) {
        this.type = type;
        this.topping = topping;
        this.qty = qty;
        this.subtotal = subtotal;
    }


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTopping() {
        return topping;
    }

    public void setTopping(String topping) {
        this.topping = topping;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public int getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(int subtotal) {
        this.subtotal = subtotal;
    }
}
