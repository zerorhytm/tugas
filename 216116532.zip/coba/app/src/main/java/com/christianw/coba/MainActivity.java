package com.christianw.coba;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {


    EditText txtNama;
    RadioGroup rbGrup;
    CheckBox cbPearl,cbPudding,cbCoconut,cbRedBean;
    Button btnPlus,btnMinus,btnAdd,btnDelete,btnReset;
    TextView txtQty,txtCustomer;
    RecyclerView rvOrder;
    RadioButton rbKopi,rbTeh,rbSmoti;

    MyAdapter Adap;
    public int idx;

    Map<String,Integer> listHarga= new HashMap<>();
    ArrayList<Order> orderku=new ArrayList<Order>();

    int qty=1;
    int tempTotal=0;
    String topping="";
    int harga=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listHarga.put("teh",23000);
        listHarga.put("kopi",25000);
        listHarga.put("smothie",30000);

        listHarga.put("pearl",3000);
        listHarga.put("red bean",3000);
        listHarga.put("pudding",4000);
        listHarga.put("coconut",4000);

        txtNama=findViewById(R.id.txtNamaBarang);
        txtCustomer=findViewById(R.id.txtCustomer);
        txtQty=findViewById(R.id.txtQty);
        txtCustomer.setText("Hi,Cust!"+"  Total: Rp 0");

        rbGrup=findViewById(R.id.radioGroup);

        cbPearl=findViewById(R.id.cbPearl);
        cbPudding=findViewById(R.id.cbPudding);
        cbCoconut=findViewById(R.id.cbCoconut);
        cbRedBean=findViewById(R.id.cbRedBean);

        rbKopi=findViewById(R.id.rbKopi);
        rbSmoti=findViewById(R.id.rbSmoti);
        rbTeh=findViewById(R.id.rbTeh);

        btnAdd=findViewById(R.id.btnAdd);
        btnDelete=findViewById(R.id.btnDelete);
        btnReset=findViewById(R.id.btnReset);
        btnPlus=findViewById(R.id.buttonPlus);
        btnMinus=findViewById(R.id.buttonMinus);

        rvOrder=findViewById(R.id.recyclerView);

        GridLayoutManager mLinearLayoutManager = new GridLayoutManager(this, 1);
        rvOrder.setLayoutManager(mLinearLayoutManager);

        final MyAdapter mAdapterSerie          = new MyAdapter(orderku);
        rvOrder.setAdapter(mAdapterSerie);


        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                orderku.clear();
                mAdapterSerie.notifyDataSetChanged();
                txtNama.setText("");
                rbTeh.setChecked(true);
                rbKopi.setChecked(false);
                rbSmoti.setChecked(false);
                qty=1;
                txtQty.setText(qty+"");
                cbCoconut.setChecked(false);
                cbPearl.setChecked(false);
                cbRedBean.setChecked(false);
                cbPudding.setChecked(false);
                txtCustomer.setText("Hi,Cust!"+"  Total: Rp 0");
            }
        });

        mAdapterSerie.setOnItemClickListener(new OnItemClickListener() {
            @Override
            //method onClick adalah method yang berada di dalam
            //Interface OnItemClickListener yang memiliki 2 parameter, yaitu
            //view yang diklik dan posisi yang diklik saat ini
            //2 parameter ini diisi di bagian MahasiswaAdapter
            public void onClick(View view, int position) {
                idx=position;
                cbPearl.setChecked(false);cbCoconut.setChecked(false);cbPudding.setChecked(false);rbSmoti.setChecked(false);
                if(idx!=-1){
                    Order temp=orderku.get(idx);
                    txtQty.setText(temp.getQty()+"");qty=temp.getQty();
                    if(temp.getTopping().contains("Pearl"))cbPearl.setChecked(true);
                    if(temp.getTopping().contains("Coconut"))cbCoconut.setChecked(true);
                    if(temp.getTopping().contains("Pudding"))cbPudding.setChecked(true);
                    if(temp.getTopping().contains("Red Bean"))cbRedBean.setChecked(true);

                    if(temp.getType().equalsIgnoreCase("Kopi"))rbKopi.setChecked(true);
                    if(temp.getType().equalsIgnoreCase("Teh"))rbTeh.setChecked(true);
                    if(temp.getType().equalsIgnoreCase("Smothie"))rbSmoti.setChecked(true);

                    txtCustomer.setText("Hi,"+txtNama.getText()+"!  Total: Rp"+temp.getSubtotal());
                }
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(txtNama.getText().toString().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Field Name cannot Be Empty",Toast.LENGTH_SHORT).show();
                }else{
                    if(cbCoconut.isChecked()){
                        topping+="Coconut,";
                        harga+=4000;
                    }
                    if(cbPearl.isChecked()){
                        topping+="Pearl,";
                        harga+=3000;
                    }
                    if(cbPudding.isChecked()){
                        topping+="Pudding,";
                        harga+=3000;
                    }
                    if(cbRedBean.isChecked()){
                        topping+="Red Bean";
                        harga+=4000;
                    }
                    int id=rbGrup.getCheckedRadioButtonId();
                    RadioButton rbTemp=findViewById(id);
                    if((rbTemp.getText()+"").equalsIgnoreCase("Smothie"))harga+=30000;
                    if((rbTemp.getText()+"").equalsIgnoreCase("Teh"))harga+=23000;
                    if((rbTemp.getText()+"").equalsIgnoreCase("Kopi"))harga+=25000;
                    Order temp=new Order(rbTemp.getText()+"", topping,qty,harga);
                    tempTotal=0;
                    orderku.add(temp);
                                for (Order order:orderku
                                     ) {
                                    tempTotal+=order.getSubtotal();
                                }
                                txtCustomer.setText("Hi,"+txtNama.getText()+"!  Total: Rp"+tempTotal);
                    mAdapterSerie.notifyDataSetChanged();
                    topping="";
                    harga=0;
                    rbTeh.setChecked(true);
                    rbKopi.setChecked(false);
                    rbSmoti.setChecked(false);
                    qty=1;
                    txtQty.setText(qty+"");
                    cbCoconut.setChecked(false);
                    cbPearl.setChecked(false);
                    cbRedBean.setChecked(false);
                    cbPudding.setChecked(false);

                }
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(idx!=-1){
                    orderku.remove(idx);idx=-1;
                }else{
                    Toast.makeText(getApplicationContext(),"Select what to delete first",Toast.LENGTH_SHORT).show();
                }
                mAdapterSerie.notifyDataSetChanged();
                rbTeh.setChecked(true);
                rbKopi.setChecked(false);
                rbSmoti.setChecked(false);
                qty=1;
                txtQty.setText(qty+"");
                cbCoconut.setChecked(false);
                cbPearl.setChecked(false);
                cbRedBean.setChecked(false);
                cbPudding.setChecked(false);
                tempTotal=0;
                for (Order order:orderku
                ) {
                    tempTotal+=order.getSubtotal();
                }
                txtCustomer.setText("Hi,"+txtNama.getText()+"!  Total: Rp"+tempTotal);
            }
        });

        btnMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(qty>1)qty--;
                txtQty.setText(qty+"");
            }
        });

        btnPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                qty++;
                txtQty.setText(qty+"");
            }
        });
    }
}
